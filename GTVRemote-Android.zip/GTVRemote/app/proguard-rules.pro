# Keep Protobuf generated classes and BouncyCastle security providers
-keep class com.tvremote.gtv.proto.** { *; }
-keep class com.google.protobuf.** { *; }
-dontwarn org.bouncycastle.**
-keep class org.bouncycastle.** { *; }
