package com.tvremote.gtv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object GtvColors {
    val Background = Color(0xFF0B0D12)
    val Surface = Color(0xFF141821)
    val SurfaceElevated = Color(0xFF1C2230)
    val SurfacePressed = Color(0xFF262E40)
    val BorderHairline = Color(0xFF252D3D)
    val TextPrimary = Color(0xFFE8EDF5)
    val TextSecondary = Color(0xFF9AA5B8)
    val AccentBlue = Color(0xFF4DA3FF)
    val StatusConnected = Color(0xFF22C55E)
    val StatusReconnecting = Color(0xFFF59E0B)
    val StatusDisconnected = Color(0xFFEF4444)
    val PowerRed = Color(0xFFE5484D)
    val YouTubeRed = Color(0xFFFF2D2D)
    val NetflixRed = Color(0xFFE50914)
}

private val DarkColorScheme = darkColorScheme(
    primary = GtvColors.AccentBlue,
    onPrimary = Color(0xFF071324),
    background = GtvColors.Background,
    onBackground = GtvColors.TextPrimary,
    surface = GtvColors.Surface,
    onSurface = GtvColors.TextPrimary,
    surfaceVariant = GtvColors.SurfaceElevated,
    onSurfaceVariant = GtvColors.TextSecondary,
    outline = GtvColors.BorderHairline,
    error = GtvColors.StatusDisconnected
)

private val AppTypography = Typography(
    titleMedium = TextStyle(
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = (-0.2).sp
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium
    )
)

@Composable
fun GtvRemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
