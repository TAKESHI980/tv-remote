package com.tvremote.gtv.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvremote.gtv.ui.PinDialogState
import com.tvremote.gtv.ui.theme.GtvColors

@Composable
fun PairingPinDialog(
    state: PinDialogState,
    onSubmitPin: (String) -> Unit,
    onCancel: () -> Unit
) {
    var pin by remember(state.host) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = GtvColors.Surface,
        titleContentColor = GtvColors.TextPrimary,
        textContentColor = GtvColors.TextSecondary,
        title = {
            Text(
                text = "Pair with ${state.tvName}",
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "Enter the 6-character hex code displayed on your TV screen.",
                    fontSize = 13.sp,
                    color = GtvColors.TextSecondary
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { input ->
                        val filtered = input.uppercase().filter {
                            it in '0'..'9' || it in 'A'..'F'
                        }.take(6)
                        pin = filtered
                    },
                    label = { Text("6-Char Hex PIN") },
                    placeholder = { Text("A4F91C") },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 4.sp,
                        color = GtvColors.TextPrimary
                    ),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { if (pin.length == 6) onSubmitPin(pin) }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GtvColors.AccentBlue,
                        unfocusedBorderColor = GtvColors.BorderHairline,
                        focusedLabelColor = GtvColors.AccentBlue
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                if (!state.error.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = state.error,
                        color = GtvColors.StatusDisconnected,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitPin(pin) },
                enabled = pin.length == 6 && !state.isVerifying,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GtvColors.AccentBlue,
                    contentColor = GtvColors.Background
                )
            ) {
                Text(if (state.isVerifying) "Verifying..." else "Pair")
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text("Cancel", color = GtvColors.TextSecondary)
            }
        }
    )
}

@Composable
fun KeyboardInputDialog(
    onSendText: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GtvColors.Surface,
        titleContentColor = GtvColors.TextPrimary,
        textContentColor = GtvColors.TextSecondary,
        title = {
            Text(
                text = "TV Keyboard Input",
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "Text is injected directly into the active TV search or text field via RemoteImeBatchEdit.",
                    fontSize = 13.sp,
                    color = GtvColors.TextSecondary
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Type movie, show, or search query...") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = { if (text.isNotEmpty()) onSendText(text) }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GtvColors.AccentBlue,
                        unfocusedBorderColor = GtvColors.BorderHairline,
                        focusedTextColor = GtvColors.TextPrimary,
                        unfocusedTextColor = GtvColors.TextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSendText(text) },
                enabled = text.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GtvColors.AccentBlue,
                    contentColor = GtvColors.Background
                )
            ) {
                Text("Send Text")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = GtvColors.TextSecondary)
            }
        }
    )
}
