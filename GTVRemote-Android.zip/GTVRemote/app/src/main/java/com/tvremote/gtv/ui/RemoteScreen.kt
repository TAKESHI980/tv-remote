package com.tvremote.gtv.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Input
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvremote.gtv.proto.RemoteProto.RemoteKeyCode
import com.tvremote.gtv.protocol.ConnectionState
import com.tvremote.gtv.ui.components.CircularDPad
import com.tvremote.gtv.ui.components.DevicePickerBottomSheet
import com.tvremote.gtv.ui.components.KeyboardInputDialog
import com.tvremote.gtv.ui.components.PairingPinDialog
import com.tvremote.gtv.ui.theme.GtvColors

@Composable
fun RemoteScreen(viewModel: RemoteViewModel) {
    val state by viewModel.uiState.collectAsState()
    val haptic = LocalHapticFeedback.current

    Scaffold(
        containerColor = GtvColors.Background,
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Top Bar: TV Name, Live Status Dot, and Switch TV button
            TopConnectionBar(
                tvName = state.activeTv?.name ?: "No TV Selected",
                connectionState = state.connectionState,
                onSwitchTv = viewModel::openDevicePicker
            )

            if (!state.statusError.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = state.statusError!!,
                    color = GtvColors.StatusReconnecting,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(16.dp))

            // 2. Power & Input Row: Power toggle, Input/Source, Mute
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RemoteActionTile(
                    icon = Icons.Rounded.PowerSettingsNew,
                    label = "Power",
                    tint = GtvColors.PowerRed,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_POWER)
                    }
                )
                RemoteActionTile(
                    icon = Icons.Rounded.Input,
                    label = "Input",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_TV_INPUT)
                    }
                )
                RemoteActionTile(
                    icon = Icons.AutoMirrored.Rounded.VolumeOff,
                    label = if (state.isMuted) "Muted" else "Mute",
                    tint = if (state.isMuted) GtvColors.AccentBlue else GtvColors.TextPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_VOLUME_MUTE)
                    }
                )
            }

            Spacer(Modifier.height(22.dp))

            // 3. Circular D-Pad
            CircularDPad(
                onUp = { viewModel.sendKey(RemoteKeyCode.KEYCODE_DPAD_UP) },
                onDown = { viewModel.sendKey(RemoteKeyCode.KEYCODE_DPAD_DOWN) },
                onLeft = { viewModel.sendKey(RemoteKeyCode.KEYCODE_DPAD_LEFT) },
                onRight = { viewModel.sendKey(RemoteKeyCode.KEYCODE_DPAD_RIGHT) },
                onOk = { viewModel.sendKey(RemoteKeyCode.KEYCODE_DPAD_CENTER) }
            )

            Spacer(Modifier.height(22.dp))

            // 4. Navigation Row: Back, Home, Settings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RemoteActionTile(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    label = "Back",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_BACK)
                    }
                )
                RemoteActionTile(
                    icon = Icons.Rounded.Home,
                    label = "Home",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_HOME)
                    }
                )
                RemoteActionTile(
                    icon = Icons.Rounded.Settings,
                    label = "Settings",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        viewModel.sendKey(RemoteKeyCode.KEYCODE_SETTINGS)
                    }
                )
            }

            Spacer(Modifier.height(18.dp))

            // 5. Volume Rocker (press-and-hold auto-repeat) + Media Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VolumeRocker(
                    onVolumeUpStart = { viewModel.startVolumeRepeat(RemoteKeyCode.KEYCODE_VOLUME_UP) },
                    onVolumeDownStart = { viewModel.startVolumeRepeat(RemoteKeyCode.KEYCODE_VOLUME_DOWN) },
                    onVolumeRelease = viewModel::stopVolumeRepeat,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = GtvColors.Surface,
                    border = BorderStroke(1.dp, GtvColors.BorderHairline),
                    modifier = Modifier
                        .weight(1.45f)
                        .height(112.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Playback",
                            color = GtvColors.TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            MediaIconButton(
                                icon = Icons.Rounded.FastRewind,
                                contentDescription = "Rewind",
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.sendKey(RemoteKeyCode.KEYCODE_MEDIA_REWIND)
                                }
                            )
                            MediaIconButton(
                                icon = Icons.Rounded.PlayArrow,
                                contentDescription = "Play/Pause",
                                highlighted = true,
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.sendKey(RemoteKeyCode.KEYCODE_MEDIA_PLAY_PAUSE)
                                }
                            )
                            MediaIconButton(
                                icon = Icons.Rounded.FastForward,
                                contentDescription = "Fast Forward",
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.sendKey(RemoteKeyCode.KEYCODE_MEDIA_FAST_FORWARD)
                                }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            // 6. Keyboard & App Launcher Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = viewModel::openKeyboardDialog,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GtvColors.BorderHairline),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = GtvColors.Surface,
                        contentColor = GtvColors.TextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Keyboard,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Keyboard", fontSize = 13.sp, maxLines = 1)
                }

                Button(
                    onClick = viewModel::launchYouTube,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GtvColors.SurfaceElevated,
                        contentColor = GtvColors.TextPrimary
                    ),
                    border = BorderStroke(1.dp, GtvColors.YouTubeRed.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text(
                        text = "YouTube",
                        color = GtvColors.YouTubeRed,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }

                Button(
                    onClick = viewModel::launchNetflix,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GtvColors.SurfaceElevated,
                        contentColor = GtvColors.TextPrimary
                    ),
                    border = BorderStroke(1.dp, GtvColors.NetflixRed.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text(
                        text = "Netflix",
                        color = GtvColors.NetflixRed,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }

    if (state.isDeviceSheetOpen) {
        DevicePickerBottomSheet(
            isScanning = state.isScanning,
            savedDevices = state.savedDevices,
            discoveredDevices = state.discoveredDevices,
            discoveryError = state.discoveryError,
            onDismiss = viewModel::closeDevicePicker,
            onRefreshScan = viewModel::refreshDiscovery,
            onSelectSaved = viewModel::connectToSavedTv,
            onForgetSaved = viewModel::forgetSavedDevice,
            onSelectDiscovered = viewModel::startPairingWithDiscovered,
            onSubmitManualIp = viewModel::startPairingWithManualIp
        )
    }

    state.pinDialog?.let { pinState ->
        PairingPinDialog(
            state = pinState,
            onSubmitPin = viewModel::submitPairingPin,
            onCancel = viewModel::cancelPairing
        )
    }

    if (state.isKeyboardDialogOpen) {
        KeyboardInputDialog(
            onSendText = viewModel::sendImeText,
            onDismiss = viewModel::closeKeyboardDialog
        )
    }
}

@Composable
private fun TopConnectionBar(
    tvName: String,
    connectionState: ConnectionState,
    onSwitchTv: () -> Unit
) {
    val (dotColor, statusText) = when (connectionState) {
        ConnectionState.Connected -> GtvColors.StatusConnected to "Connected"
        ConnectionState.Connecting -> GtvColors.StatusReconnecting to "Connecting"
        ConnectionState.Reconnecting -> GtvColors.StatusReconnecting to "Reconnecting"
        ConnectionState.Disconnected -> GtvColors.StatusDisconnected to "Disconnected"
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = GtvColors.Surface,
        border = BorderStroke(1.dp, GtvColors.BorderHairline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tvName,
                    color = GtvColors.TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        color = GtvColors.TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            OutlinedButton(
                onClick = onSwitchTv,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GtvColors.BorderHairline),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = GtvColors.SurfaceElevated,
                    contentColor = GtvColors.TextPrimary
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.SwapHoriz,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text("Switch TV", fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun RemoteActionTile(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    tint: Color = GtvColors.TextPrimary,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = GtvColors.Surface,
        border = BorderStroke(1.dp, GtvColors.BorderHairline),
        modifier = modifier.height(68.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = GtvColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun VolumeRocker(
    onVolumeUpStart: () -> Unit,
    onVolumeDownStart: () -> Unit,
    onVolumeRelease: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = GtvColors.Surface,
        border = BorderStroke(1.dp, GtvColors.BorderHairline),
        modifier = modifier.height(112.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onVolumeUpStart()
                                try {
                                    awaitRelease()
                                } finally {
                                    onVolumeRelease()
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.VolumeUp,
                    contentDescription = "Volume Up",
                    tint = GtvColors.TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(GtvColors.BorderHairline)
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onVolumeDownStart()
                                try {
                                    awaitRelease()
                                } finally {
                                    onVolumeRelease()
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.VolumeDown,
                    contentDescription = "Volume Down",
                    tint = GtvColors.TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun MediaIconButton(
    icon: ImageVector,
    contentDescription: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = if (highlighted) GtvColors.SurfacePressed else GtvColors.SurfaceElevated,
        border = BorderStroke(
            width = 1.dp,
            color = if (highlighted) GtvColors.AccentBlue.copy(alpha = 0.45f) else GtvColors.BorderHairline
        ),
        modifier = Modifier.size(48.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = GtvColors.TextPrimary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
