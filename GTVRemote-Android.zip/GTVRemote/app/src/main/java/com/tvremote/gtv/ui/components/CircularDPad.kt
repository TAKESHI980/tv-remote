package com.tvremote.gtv.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvremote.gtv.ui.theme.GtvColors

@Composable
fun CircularDPad(
    onUp: () -> Unit,
    onDown: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onOk: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .size(236.dp)
            .clip(CircleShape)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        GtvColors.SurfaceElevated,
                        GtvColors.Surface
                    )
                )
            )
            .border(1.dp, GtvColors.BorderHairline, CircleShape)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        DPadDirectionButton(
            icon = Icons.Rounded.KeyboardArrowUp,
            contentDescription = "Up",
            modifier = Modifier.align(Alignment.TopCenter),
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onUp()
            }
        )

        DPadDirectionButton(
            icon = Icons.Rounded.KeyboardArrowDown,
            contentDescription = "Down",
            modifier = Modifier.align(Alignment.BottomCenter),
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onDown()
            }
        )

        DPadDirectionButton(
            icon = Icons.Rounded.KeyboardArrowLeft,
            contentDescription = "Left",
            modifier = Modifier.align(Alignment.CenterStart),
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onLeft()
            }
        )

        DPadDirectionButton(
            icon = Icons.Rounded.KeyboardArrowRight,
            contentDescription = "Right",
            modifier = Modifier.align(Alignment.CenterEnd),
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onRight()
            }
        )

        Surface(
            modifier = Modifier
                .size(86.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = GtvColors.AccentBlue)
                ) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onOk()
                },
            shape = CircleShape,
            color = GtvColors.SurfacePressed,
            border = BorderStroke(1.dp, GtvColors.AccentBlue.copy(alpha = 0.45f))
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text(
                    text = "OK",
                    color = GtvColors.TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun DPadDirectionButton(
    icon: ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = GtvColors.AccentBlue),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = GtvColors.TextPrimary,
            modifier = Modifier.size(30.dp)
        )
    }
}
