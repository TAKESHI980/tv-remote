package com.tvremote.gtv.protocol

import android.os.Build
import com.tvremote.gtv.proto.RemoteProto.RemoteAppLinkLaunchRequest
import com.tvremote.gtv.proto.RemoteProto.RemoteConfigure
import com.tvremote.gtv.proto.RemoteProto.RemoteDeviceInfo
import com.tvremote.gtv.proto.RemoteProto.RemoteDirection
import com.tvremote.gtv.proto.RemoteProto.RemoteEditInfo
import com.tvremote.gtv.proto.RemoteProto.RemoteImeBatchEdit
import com.tvremote.gtv.proto.RemoteProto.RemoteImeObject
import com.tvremote.gtv.proto.RemoteProto.RemoteKeyCode
import com.tvremote.gtv.proto.RemoteProto.RemoteKeyInject
import com.tvremote.gtv.proto.RemoteProto.RemoteMessage
import com.tvremote.gtv.proto.RemoteProto.RemotePingResponse
import com.tvremote.gtv.proto.RemoteProto.RemoteSetActive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import kotlin.math.min

enum class ConnectionState {
    Disconnected,
    Connecting,
    Connected,
    Reconnecting
}

data class SessionVolumeState(
    val level: Int = 0,
    val max: Int = 100,
    val muted: Boolean = false
)

class RemoteSessionClient(private val certificateManager: CertificateManager) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writeMutex = Mutex()

    private var sessionJob: Job? = null
    private var activeSocket: SSLSocket? = null
    private var activeOutput: BufferedOutputStream? = null
    private var imeCounter = 1
    private var fieldCounter = 1

    private val _connectionState = MutableStateFlow(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _volumeState = MutableStateFlow(SessionVolumeState())
    val volumeState: StateFlow<SessionVolumeState> = _volumeState.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    fun connect(host: String, port: Int = REMOTE_PORT) {
        disconnect()
        sessionJob = scope.launch {
            var attempt = 0
            while (isActive) {
                _connectionState.value = if (attempt == 0) {
                    ConnectionState.Connecting
                } else {
                    ConnectionState.Reconnecting
                }

                val sessionCleanlyEnded = runSingleSession(host, port)
                if (!isActive || sessionCleanlyEnded) break

                attempt++
                _connectionState.value = ConnectionState.Reconnecting
                val backoffMs = min(MAX_BACKOFF_MS, INITIAL_BACKOFF_MS * (1L shl min(attempt - 1, 5)))
                delay(backoffMs)
            }
        }
    }

    fun disconnect() {
        sessionJob?.cancel()
        sessionJob = null
        closeSocket()
        _connectionState.value = ConnectionState.Disconnected
    }

    suspend fun sendKey(
        keyCode: RemoteKeyCode,
        direction: RemoteDirection = RemoteDirection.SHORT
    ): Boolean {
        val message = RemoteMessage.newBuilder()
            .setRemoteKeyInject(
                RemoteKeyInject.newBuilder()
                    .setKeyCode(keyCode)
                    .setDirection(direction)
                    .build()
            )
            .build()
        return writeMessage(message)
    }

    suspend fun sendTextBatch(text: String): Boolean {
        if (text.isEmpty()) return false
        val editInfo = RemoteEditInfo.newBuilder()
            .setInsert(1)
            .setTextFieldStatus(
                RemoteImeObject.newBuilder()
                    .setStart(0)
                    .setEnd(text.length)
                    .setValue(text)
                    .build()
            )
            .build()

        val message = RemoteMessage.newBuilder()
            .setRemoteImeBatchEdit(
                RemoteImeBatchEdit.newBuilder()
                    .setImeCounter(imeCounter++)
                    .setFieldCounter(fieldCounter)
                    .addEditInfo(editInfo)
                    .build()
            )
            .build()
        return writeMessage(message)
    }

    suspend fun launchAppLink(appLinkUrl: String): Boolean {
        val message = RemoteMessage.newBuilder()
            .setRemoteAppLinkLaunchRequest(
                RemoteAppLinkLaunchRequest.newBuilder()
                    .setAppLink(appLinkUrl)
                    .build()
            )
            .build()
        return writeMessage(message)
    }

    private suspend fun runSingleSession(host: String, port: Int): Boolean {
        var sslSocket: SSLSocket? = null
        return try {
            val sslContext = certificateManager.createMutualTlsContext()
            sslSocket = (sslContext.socketFactory.createSocket() as SSLSocket).apply {
                soTimeout = 30_000
                tcpNoDelay = true
                keepAlive = true
                connect(InetSocketAddress(host, port), 8_000)
                useClientMode = true
                startHandshake()
            }
            activeSocket = sslSocket
            val input = BufferedInputStream(sslSocket.inputStream)
            val output = BufferedOutputStream(sslSocket.outputStream)
            activeOutput = output
            _lastError.value = null

            // Read loop handling handshake, ping heartbeats, IME state, and volume updates
            while (scope.isActive && !sslSocket.isClosed) {
                val frameBytes = VarintFraming.readDelimitedBytes(input)
                val incoming = RemoteMessage.parseFrom(frameBytes)

                when (incoming.messageCase) {
                    RemoteMessage.MessageCase.REMOTE_CONFIGURE -> {
                        sendClientConfigure()
                    }
                    RemoteMessage.MessageCase.REMOTE_SET_ACTIVE -> {
                        sendClientSetActive()
                    }
                    RemoteMessage.MessageCase.REMOTE_START -> {
                        if (incoming.remoteStart.started) {
                            _connectionState.value = ConnectionState.Connected
                        }
                    }
                    RemoteMessage.MessageCase.REMOTE_PING_REQUEST -> {
                        val pingVal = incoming.remotePingRequest.val1
                        writeMessage(
                            RemoteMessage.newBuilder()
                                .setRemotePingResponse(
                                    RemotePingResponse.newBuilder()
                                        .setVal1(pingVal)
                                        .build()
                                )
                                .build()
                        )
                    }
                    RemoteMessage.MessageCase.REMOTE_IME_SHOW_REQUEST -> {
                        fieldCounter = incoming.remoteImeShowRequest.remoteTextFieldStatus.counterField
                    }
                    RemoteMessage.MessageCase.REMOTE_SET_VOLUME_LEVEL -> {
                        val vol = incoming.remoteSetVolumeLevel
                        _volumeState.value = SessionVolumeState(
                            level = vol.volumeLevel,
                            max = vol.volumeMax.coerceAtLeast(1),
                            muted = vol.volumeMuted
                        )
                    }
                    RemoteMessage.MessageCase.REMOTE_ERROR -> {
                        _lastError.value = "TV reported remote protocol error"
                    }
                    else -> Unit
                }
            }
            false
        } catch (e: Exception) {
            _lastError.value = e.message ?: "Remote session disconnected"
            false
        } finally {
            closeSocket()
        }
    }

    private suspend fun sendClientConfigure() {
        val deviceInfo = RemoteDeviceInfo.newBuilder()
            .setModel(Build.MODEL.ifBlank { "Android Phone" })
            .setVendor(Build.MANUFACTURER.ifBlank { "Android" })
            .setUnknown1(1)
            .setUnknown2(Build.VERSION.RELEASE ?: "14")
            .setPackageName("com.tvremote.gtv")
            .setAppVersion("1.0.0")
            .build()

        val msg = RemoteMessage.newBuilder()
            .setRemoteConfigure(
                RemoteConfigure.newBuilder()
                    .setCode1(CLIENT_CAPABILITIES_MASK)
                    .setDeviceInfo(deviceInfo)
                    .build()
            )
            .build()
        writeMessage(msg)
    }

    private suspend fun sendClientSetActive() {
        val msg = RemoteMessage.newBuilder()
            .setRemoteSetActive(
                RemoteSetActive.newBuilder()
                    .setActive(CLIENT_CAPABILITIES_MASK)
                    .build()
            )
            .build()
        writeMessage(msg)
    }

    private suspend fun writeMessage(message: RemoteMessage): Boolean {
        return writeMutex.withLock {
            val out = activeOutput ?: return@withLock false
            runCatching {
                VarintFraming.writeDelimited(out, message)
                true
            }.onFailure { err ->
                _lastError.value = err.message ?: "Failed to send command"
                closeSocket()
            }.getOrDefault(false)
        }
    }

    private fun closeSocket() {
        activeOutput = null
        runCatching { activeSocket?.close() }
        activeSocket = null
    }

    companion object {
        const val REMOTE_PORT = 6466
        private const val CLIENT_CAPABILITIES_MASK = 622
        private const val INITIAL_BACKOFF_MS = 1_000L
        private const val MAX_BACKOFF_MS = 30_000L
    }
}
