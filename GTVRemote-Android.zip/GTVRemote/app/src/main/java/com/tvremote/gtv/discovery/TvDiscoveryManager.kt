package com.tvremote.gtv.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.net.Inet4Address
import kotlin.coroutines.resume

data class DiscoveredTv(
    val serviceName: String,
    val displayName: String,
    val host: String,
    val port: Int
)

class TvDiscoveryManager(context: Context) {

    private val appContext = context.applicationContext
    private val nsdManager = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var multicastLock: WifiManager.MulticastLock? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var resolveQueueJob: Job? = null
    private var resolveChannel: Channel<NsdServiceInfo>? = null

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredTv>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredTv>> = _discoveredDevices.asStateFlow()

    private val _discoveryError = MutableStateFlow<String?>(null)
    val discoveryError: StateFlow<String?> = _discoveryError.asStateFlow()

    fun startDiscovery() {
        if (_isScanning.value) return
        _discoveryError.value = null
        _discoveredDevices.value = emptyList()

        acquireMulticastLock()

        val channel = Channel<NsdServiceInfo>(Channel.UNLIMITED)
        resolveChannel = channel
        resolveQueueJob = scope.launch {
            for (serviceInfo in channel) {
                val resolved = resolveServiceSequentially(serviceInfo)
                if (resolved != null) {
                    upsertDevice(resolved)
                }
            }
        }

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                _isScanning.value = true
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (serviceInfo.serviceType.contains(SERVICE_TYPE_PREFIX)) {
                    resolveChannel?.trySend(serviceInfo)
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                val lostName = serviceInfo.serviceName
                _discoveredDevices.value = _discoveredDevices.value.filterNot {
                    it.serviceName == lostName
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                _isScanning.value = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                _discoveryError.value = "mDNS discovery failed to start (code $errorCode)"
                stopDiscovery()
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                _isScanning.value = false
                releaseMulticastLock()
            }
        }

        discoveryListener = listener
        runCatching {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure { err ->
            _discoveryError.value = err.message ?: "Unable to start NsdManager discovery"
            stopDiscovery()
        }
    }

    fun stopDiscovery() {
        discoveryListener?.let { listener ->
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }
        discoveryListener = null
        resolveChannel?.close()
        resolveChannel = null
        resolveQueueJob?.cancel()
        resolveQueueJob = null
        _isScanning.value = false
        releaseMulticastLock()
    }

    private suspend fun resolveServiceSequentially(serviceInfo: NsdServiceInfo): DiscoveredTv? {
        return withTimeoutOrNull(4_000L) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                resolveApi34(serviceInfo)
            } else {
                resolveLegacy(serviceInfo)
            }
        }
    }

    private suspend fun resolveApi34(serviceInfo: NsdServiceInfo): DiscoveredTv? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return null
        return suspendCancellableCoroutine { cont ->
            var callbackRef: NsdManager.ServiceInfoCallback? = null
            val callback = object : NsdManager.ServiceInfoCallback {
                override fun onServiceInfoCallbackRegistrationFailed(errorCode: Int) {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onServiceUpdated(updatedInfo: NsdServiceInfo) {
                    val host = updatedInfo.hostAddresses
                        .firstOrNull { it is Inet4Address }?.hostAddress
                        ?: updatedInfo.hostAddresses.firstOrNull()?.hostAddress
                    if (!host.isNullOrBlank() && cont.isActive) {
                        runCatching { nsdManager.unregisterServiceInfoCallback(this) }
                        cont.resume(
                            DiscoveredTv(
                                serviceName = updatedInfo.serviceName,
                                displayName = cleanDisplayName(updatedInfo.serviceName),
                                host = host,
                                port = if (updatedInfo.port > 0) updatedInfo.port else 6466
                            )
                        )
                    }
                }

                override fun onServiceLost() {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onServiceInfoCallbackUnregistered() = Unit
            }
            callbackRef = callback
            runCatching {
                nsdManager.registerServiceInfoCallback(serviceInfo, Runnable::run, callback)
            }.onFailure {
                if (cont.isActive) cont.resume(null)
            }
            cont.invokeOnCancellation {
                callbackRef?.let { cb ->
                    runCatching { nsdManager.unregisterServiceInfoCallback(cb) }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun resolveLegacy(serviceInfo: NsdServiceInfo): DiscoveredTv? {
        return suspendCancellableCoroutine { cont ->
            val listener = object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                    if (cont.isActive) cont.resume(null)
                }

                override fun onServiceResolved(resolved: NsdServiceInfo) {
                    val host = resolved.host?.hostAddress
                    val result = if (!host.isNullOrBlank()) {
                        DiscoveredTv(
                            serviceName = resolved.serviceName,
                            displayName = cleanDisplayName(resolved.serviceName),
                            host = host,
                            port = if (resolved.port > 0) resolved.port else 6466
                        )
                    } else {
                        null
                    }
                    if (cont.isActive) cont.resume(result)
                }
            }
            runCatching {
                nsdManager.resolveService(serviceInfo, listener)
            }.onFailure {
                if (cont.isActive) cont.resume(null)
            }
        }
    }

    private fun upsertDevice(tv: DiscoveredTv) {
        val current = _discoveredDevices.value.toMutableList()
        val idx = current.indexOfFirst { it.host == tv.host }
        if (idx >= 0) {
            current[idx] = tv
        } else {
            current.add(tv)
        }
        _discoveredDevices.value = current.sortedBy { it.displayName.lowercase() }
    }

    private fun cleanDisplayName(raw: String): String {
        return raw
            .removeSuffix("._androidtvremote2._tcp.")
            .removeSuffix("._androidtvremote2._tcp")
            .trim()
            .ifEmpty { raw }
    }

    private fun acquireMulticastLock() {
        runCatching {
            if (multicastLock == null) {
                multicastLock = wifiManager.createMulticastLock("gtv_remote_mdns_lock").apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        }
    }

    companion object {
        const val SERVICE_TYPE = "_androidtvremote2._tcp."
        private const val SERVICE_TYPE_PREFIX = "_androidtvremote2._tcp"
    }
}
