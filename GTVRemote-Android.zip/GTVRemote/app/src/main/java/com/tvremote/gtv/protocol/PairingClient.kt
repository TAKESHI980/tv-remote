package com.tvremote.gtv.protocol

import android.os.Build
import com.tvremote.gtv.proto.PairingProto.EncodingType
import com.tvremote.gtv.proto.PairingProto.PairingConfiguration
import com.tvremote.gtv.proto.PairingProto.PairingEncoding
import com.tvremote.gtv.proto.PairingProto.PairingMessage
import com.tvremote.gtv.proto.PairingProto.PairingOption
import com.tvremote.gtv.proto.PairingProto.PairingRequest
import com.tvremote.gtv.proto.PairingProto.PairingSecret
import com.tvremote.gtv.proto.PairingProto.RoleType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.SSLSocket

sealed interface PairingResult {
    data class Success(val serverName: String) : PairingResult
    data class Failure(val reason: String) : PairingResult
}

class PairingClient(private val certificateManager: CertificateManager) {

    suspend fun pairWithTv(
        host: String,
        port: Int = PAIRING_PORT,
        onReadyForPin: suspend (tvDisplayName: String) -> String
    ): PairingResult = withContext(Dispatchers.IO) {
        val peerCertRef = AtomicReference<X509Certificate?>(null)
        var socket: SSLSocket? = null

        try {
            val sslContext = certificateManager.createMutualTlsContext(peerCertRef)
            val sslSocket = (sslContext.socketFactory.createSocket() as SSLSocket).apply {
                soTimeout = 60_000
                connect(InetSocketAddress(host, port), 8_000)
                useClientMode = true
                startHandshake()
            }
            socket = sslSocket

            val input = BufferedInputStream(sslSocket.inputStream)
            val output = BufferedOutputStream(sslSocket.outputStream)

            val clientCert = certificateManager.getOrCreateIdentity().certificate
            val serverCert = peerCertRef.get()
                ?: (sslSocket.session.peerCertificates.firstOrNull() as? X509Certificate)
                ?: return@withContext PairingResult.Failure("TV did not present an X.509 certificate")

            // 1. Send PairingRequest
            val clientModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifEmpty { "Android Remote" }
            val requestMsg = PairingMessage.newBuilder()
                .setProtocolVersion(PROTOCOL_VERSION)
                .setStatus(PairingMessage.Status.STATUS_OK)
                .setPairingRequest(
                    PairingRequest.newBuilder()
                        .setServiceName(SERVICE_NAME)
                        .setClientName(clientModel)
                        .build()
                )
                .build()
            VarintFraming.writeDelimited(output, requestMsg)

            val reqAck = readPairingMessage(input)
            if (reqAck.status != PairingMessage.Status.STATUS_OK || !reqAck.hasPairingRequestAck()) {
                return@withContext PairingResult.Failure("PairingRequest rejected (${reqAck.status})")
            }
            val serverName = reqAck.pairingRequestAck.serverName.ifBlank { host }

            // 2. Send PairingOption
            val hexEncoding = PairingEncoding.newBuilder()
                .setType(EncodingType.ENCODING_TYPE_HEXADECIMAL)
                .setSymbolLength(6)
                .build()

            val optionMsg = PairingMessage.newBuilder()
                .setProtocolVersion(PROTOCOL_VERSION)
                .setStatus(PairingMessage.Status.STATUS_OK)
                .setPairingOption(
                    PairingOption.newBuilder()
                        .addInputEncodings(hexEncoding)
                        .setPreferredRole(RoleType.ROLE_TYPE_INPUT)
                        .build()
                )
                .build()
            VarintFraming.writeDelimited(output, optionMsg)

            val optionAck = readPairingMessage(input)
            if (optionAck.status != PairingMessage.Status.STATUS_OK || !optionAck.hasPairingOption()) {
                return@withContext PairingResult.Failure("PairingOption negotiation failed (${optionAck.status})")
            }

            // 3. Send PairingConfiguration
            val configMsg = PairingMessage.newBuilder()
                .setProtocolVersion(PROTOCOL_VERSION)
                .setStatus(PairingMessage.Status.STATUS_OK)
                .setPairingConfiguration(
                    PairingConfiguration.newBuilder()
                        .setEncoding(hexEncoding)
                        .setClientRole(RoleType.ROLE_TYPE_INPUT)
                        .build()
                )
                .build()
            VarintFraming.writeDelimited(output, configMsg)

            val configAck = readPairingMessage(input)
            if (configAck.status != PairingMessage.Status.STATUS_OK || !configAck.hasPairingConfigurationAck()) {
                return@withContext PairingResult.Failure("PairingConfiguration rejected (${configAck.status})")
            }

            // 4. Prompt UI for 6-character hex PIN shown on TV
            val pin = onReadyForPin(serverName).trim().uppercase()
            val pinBytes = parseHexPin(pin)
                ?: return@withContext PairingResult.Failure("PIN must be exactly 6 hexadecimal characters")

            // 5. Compute SHA-256 over unsigned client/server RSA modulus+exponent + last 2 bytes of PIN
            val digest = computePairingDigest(clientCert, serverCert, pinBytes)
            if (digest[0] != pinBytes[0]) {
                return@withContext PairingResult.Failure("Incorrect PIN — check the 6-character code on your TV")
            }

            // 6. Send PairingSecret
            val secretMsg = PairingMessage.newBuilder()
                .setProtocolVersion(PROTOCOL_VERSION)
                .setStatus(PairingMessage.Status.STATUS_OK)
                .setPairingSecret(
                    PairingSecret.newBuilder()
                        .setSecret(com.google.protobuf.ByteString.copyFrom(digest))
                        .build()
                )
                .build()
            VarintFraming.writeDelimited(output, secretMsg)

            val secretAck = readPairingMessage(input)
            if (secretAck.status != PairingMessage.Status.STATUS_OK || !secretAck.hasPairingSecretAck()) {
                return@withContext PairingResult.Failure("TV rejected pairing secret (${secretAck.status})")
            }

            PairingResult.Success(serverName)
        } catch (e: Exception) {
            PairingResult.Failure(e.message ?: "Pairing connection error")
        } finally {
            runCatching { socket?.close() }
        }
    }

    private fun readPairingMessage(input: BufferedInputStream): PairingMessage {
        val bytes = VarintFraming.readDelimitedBytes(input)
        return PairingMessage.parseFrom(bytes)
    }

    companion object {
        const val PAIRING_PORT = 6467
        private const val PROTOCOL_VERSION = 2
        private const val SERVICE_NAME = "androidtvremote2"

        fun parseHexPin(pin: String): ByteArray? {
            val clean = pin.trim()
            if (clean.length != 6 || !clean.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
                return null
            }
            return ByteArray(3) { i ->
                clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
        }

        fun computePairingDigest(
            clientCert: X509Certificate,
            serverCert: X509Certificate,
            pinBytes: ByteArray
        ): ByteArray {
            val (clientMod, clientExp) = CertificateManager.extractRsaParamsUnsigned(clientCert)
            val (serverMod, serverExp) = CertificateManager.extractRsaParamsUnsigned(serverCert)
            val md = MessageDigest.getInstance("SHA-256")
            md.update(clientMod)
            md.update(clientExp)
            md.update(serverMod)
            md.update(serverExp)
            md.update(pinBytes, 1, 2)
            return md.digest()
        }
    }
}

class PinPromptChannel {
    private var deferred: CompletableDeferred<String>? = null

    fun createRequest(): CompletableDeferred<String> {
        deferred?.cancel()
        return CompletableDeferred<String>().also { deferred = it }
    }

    fun submitPin(pin: String) {
        deferred?.complete(pin)
    }

    fun cancel() {
        deferred?.cancel()
        deferred = null
    }
}
