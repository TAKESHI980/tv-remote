package com.tvremote.gtv.protocol

import android.content.Context
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Security
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

data class ClientIdentity(
    val certificate: X509Certificate,
    val privateKey: PrivateKey
)

class CertificateManager(private val context: Context) {

    init {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(BouncyCastleProvider())
        }
    }

    private val certFile: File get() = File(context.filesDir, CERT_FILE_NAME)
    private val keyFile: File get() = File(context.filesDir, KEY_FILE_NAME)

    @Synchronized
    fun getOrCreateIdentity(): ClientIdentity {
        if (certFile.exists() && keyFile.exists()) {
            runCatching {
                val certBytes = certFile.readBytes()
                val keyBytes = keyFile.readBytes()
                val certFactory = CertificateFactory.getInstance("X.509")
                val cert = certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
                val keySpec = PKCS8EncodedKeySpec(keyBytes)
                val privateKey = KeyFactory.getInstance("RSA").generatePrivate(keySpec)
                return ClientIdentity(cert, privateKey)
            }
        }

        val generated = generateSelfSignedRsa2048()
        certFile.writeBytes(generated.certificate.encoded)
        keyFile.writeBytes(generated.privateKey.encoded)
        return generated
    }

    fun createMutualTlsContext(
        peerCertificateOut: AtomicReference<X509Certificate?>? = null
    ): SSLContext {
        val identity = getOrCreateIdentity()
        val keyStore = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setKeyEntry(
                "client",
                identity.privateKey,
                KEYSTORE_PASS,
                arrayOf(identity.certificate)
            )
        }

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply {
            init(keyStore, KEYSTORE_PASS)
        }

        val trustManager = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit

            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                val leaf = chain?.firstOrNull()
                if (leaf != null) {
                    peerCertificateOut?.set(leaf)
                }
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }

        return SSLContext.getInstance("TLSv1.2").apply {
            init(kmf.keyManagers, arrayOf<TrustManager>(trustManager), SecureRandom())
        }
    }

    private fun generateSelfSignedRsa2048(): ClientIdentity {
        val keyPairGen = KeyPairGenerator.getInstance("RSA").apply {
            initialize(2048, SecureRandom())
        }
        val keyPair = keyPairGen.generateKeyPair()

        val now = System.currentTimeMillis()
        val notBefore = Date(now - 86_400_000L)
        val notAfter = Date(now + 10L * 365L * 86_400_000L)
        val serial = BigInteger(64, SecureRandom()).abs().max(BigInteger.ONE)
        val subject = X500Name("CN=GTVRemoteClient, O=GTVRemote, C=US")

        val certBuilder = JcaX509v3CertificateBuilder(
            subject,
            serial,
            notBefore,
            notAfter,
            subject,
            keyPair.public
        )

        val signer = JcaContentSignerBuilder("SHA256WithRSA")
            .build(keyPair.private)

        val holder = certBuilder.build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(holder)
        return ClientIdentity(cert, keyPair.private)
    }

    companion object {
        private const val CERT_FILE_NAME = "atv_remote_client_cert.der"
        private const val KEY_FILE_NAME = "atv_remote_client_pkcs8.der"
        private val KEYSTORE_PASS = "gtvremote".toCharArray()

        fun extractRsaParamsUnsigned(certificate: X509Certificate): Pair<ByteArray, ByteArray> {
            val rsaPub = certificate.publicKey as? RSAPublicKey
                ?: throw IllegalStateException("Certificate public key is not RSA")
            return rsaPub.modulus.toUnsignedBigEndian() to rsaPub.publicExponent.toUnsignedBigEndian()
        }

        fun BigInteger.toUnsignedBigEndian(): ByteArray {
            val raw = toByteArray()
            var start = 0
            while (start < raw.size - 1 && raw[start] == 0.toByte()) {
                start++
            }
            return if (start == 0) raw else raw.copyOfRange(start, raw.size)
        }
    }
}
