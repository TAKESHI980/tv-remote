package com.tvremote.gtv.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class SavedTvDevice(
    val name: String,
    val host: String,
    val port: Int = DEFAULT_REMOTE_PORT,
    val lastConnectedEpochMs: Long = System.currentTimeMillis()
) {
    companion object {
        const val DEFAULT_REMOTE_PORT = 6466
        const val DEFAULT_PAIRING_PORT = 6467
    }
}

class PairedTvRepository(context: Context) {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _savedDevices = MutableStateFlow(loadSavedDevices())
    val savedDevices: StateFlow<List<SavedTvDevice>> = _savedDevices.asStateFlow()

    fun getLastConnectedDevice(): SavedTvDevice? {
        val lastHost = prefs.getString(KEY_LAST_HOST, null) ?: return _savedDevices.value.firstOrNull()
        return _savedDevices.value.firstOrNull { it.host == lastHost }
            ?: _savedDevices.value.firstOrNull()
    }

    fun savePairedDevice(device: SavedTvDevice) {
        val updated = _savedDevices.value
            .filterNot { it.host == device.host }
            .toMutableList()
            .apply {
                add(0, device.copy(lastConnectedEpochMs = System.currentTimeMillis()))
            }

        persistDevices(updated)
        prefs.edit()
            .putString(KEY_LAST_HOST, device.host)
            .apply()
        _savedDevices.value = updated
    }

    fun removePairedDevice(host: String) {
        val updated = _savedDevices.value.filterNot { it.host == host }
        persistDevices(updated)
        if (prefs.getString(KEY_LAST_HOST, null) == host) {
            prefs.edit().putString(KEY_LAST_HOST, updated.firstOrNull()?.host).apply()
        }
        _savedDevices.value = updated
    }

    fun setLastConnectedHost(host: String) {
        prefs.edit().putString(KEY_LAST_HOST, host).apply()
    }

    private fun loadSavedDevices(): List<SavedTvDevice> {
        val raw = prefs.getString(KEY_DEVICES_JSON, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        SavedTvDevice(
                            name = obj.getString("name"),
                            host = obj.getString("host"),
                            port = obj.optInt("port", SavedTvDevice.DEFAULT_REMOTE_PORT),
                            lastConnectedEpochMs = obj.optLong("lastConnectedEpochMs", 0L)
                        )
                    )
                }
            }.sortedByDescending { it.lastConnectedEpochMs }
        }.getOrDefault(emptyList())
    }

    private fun persistDevices(devices: List<SavedTvDevice>) {
        val array = JSONArray()
        devices.forEach { device ->
            array.put(
                JSONObject().apply {
                    put("name", device.name)
                    put("host", device.host)
                    put("port", device.port)
                    put("lastConnectedEpochMs", device.lastConnectedEpochMs)
                }
            )
        }
        prefs.edit().putString(KEY_DEVICES_JSON, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "gtv_remote_paired_devices"
        private const val KEY_DEVICES_JSON = "paired_devices_json"
        private const val KEY_LAST_HOST = "last_connected_host"
    }
}
