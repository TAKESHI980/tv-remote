package com.tvremote.gtv.protocol

import com.google.protobuf.MessageLite
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

object VarintFraming {

    private const val MAX_FRAME_SIZE_BYTES = 1_048_576 // 1 MiB safety cap

    @Throws(IOException::class)
    fun writeDelimited(output: OutputStream, message: MessageLite) {
        val payload = message.toByteArray()
        writeRawVarint32(output, payload.size)
        output.write(payload)
        output.flush()
    }

    @Throws(IOException::class)
    fun readDelimitedBytes(input: InputStream): ByteArray {
        val length = readRawVarint32(input)
        if (length < 0 || length > MAX_FRAME_SIZE_BYTES) {
            throw IOException("Invalid protobuf varint frame size: $length")
        }
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val read = input.read(buffer, offset, length - offset)
            if (read == -1) {
                throw EOFException("Unexpected EOF while reading protobuf frame ($offset/$length)")
            }
            offset += read
        }
        return buffer
    }

    @Throws(IOException::class)
    fun writeRawVarint32(output: OutputStream, valueInput: Int) {
        var value = valueInput
        while ((value and -0x80) != 0) {
            output.write((value and 0x7F) or 0x80)
            value = value ushr 7
        }
        output.write(value and 0x7F)
    }

    @Throws(IOException::class)
    fun readRawVarint32(input: InputStream): Int {
        var result = 0
        var shift = 0
        while (shift < 32) {
            val b = input.read()
            if (b == -1) {
                throw EOFException("Socket closed while reading varint length")
            }
            result = result or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) {
                return result
            }
            shift += 7
        }
        throw IOException("Malformed varint32 in stream")
    }
}
