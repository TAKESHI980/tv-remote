package com.tvremote.gtv.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvremote.gtv.data.PairedTvRepository
import com.tvremote.gtv.data.SavedTvDevice
import com.tvremote.gtv.discovery.DiscoveredTv
import com.tvremote.gtv.discovery.TvDiscoveryManager
import com.tvremote.gtv.proto.RemoteProto.RemoteDirection
import com.tvremote.gtv.proto.RemoteProto.RemoteKeyCode
import com.tvremote.gtv.protocol.CertificateManager
import com.tvremote.gtv.protocol.ConnectionState
import com.tvremote.gtv.protocol.PairingClient
import com.tvremote.gtv.protocol.PairingResult
import com.tvremote.gtv.protocol.PinPromptChannel
import com.tvremote.gtv.protocol.RemoteSessionClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PinDialogState(
    val tvName: String,
    val host: String,
    val error: String? = null,
    val isVerifying: Boolean = false
)

data class RemoteUiState(
    val activeTv: SavedTvDevice? = null,
    val connectionState: ConnectionState = ConnectionState.Disconnected,
    val statusError: String? = null,
    val isDeviceSheetOpen: Boolean = false,
    val isScanning: Boolean = false,
    val discoveredDevices: List<DiscoveredTv> = emptyList(),
    val savedDevices: List<SavedTvDevice> = emptyList(),
    val discoveryError: String? = null,
    val pinDialog: PinDialogState? = null,
    val isKeyboardDialogOpen: Boolean = false,
    val isMuted: Boolean = false
)

class RemoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PairedTvRepository(application)
    private val discoveryManager = TvDiscoveryManager(application)
    private val certificateManager = CertificateManager(application)
    private val pairingClient = PairingClient(certificateManager)
    private val sessionClient = RemoteSessionClient(certificateManager)
    private val pinPromptChannel = PinPromptChannel()

    private val _activeTv = MutableStateFlow<SavedTvDevice?>(null)
    private val _isDeviceSheetOpen = MutableStateFlow(false)
    private val _pinDialog = MutableStateFlow<PinDialogState?>(null)
    private val _isKeyboardDialogOpen = MutableStateFlow(false)
    private val _localError = MutableStateFlow<String?>(null)

    private var pairingJob: Job? = null
    private var volumeRepeatJob: Job? = null

    private val discoveryUiFlow = combine(
        _isDeviceSheetOpen,
        discoveryManager.isScanning,
        discoveryManager.discoveredDevices,
        repository.savedDevices,
        discoveryManager.discoveryError
    ) { sheetOpen, scanning, discovered, saved, discErr ->
        DiscoverySlice(sheetOpen, scanning, discovered, saved, discErr)
    }

    private val sessionUiFlow = combine(
        _activeTv,
        sessionClient.connectionState,
        sessionClient.lastError,
        _localError,
        sessionClient.volumeState
    ) { activeTv, connState, sErr, lErr, vol ->
        SessionSlice(activeTv, connState, lErr ?: sErr, vol.muted)
    }

    val uiState: StateFlow<RemoteUiState> = combine(
        sessionUiFlow,
        discoveryUiFlow,
        _pinDialog,
        _isKeyboardDialogOpen
    ) { session, discovery, pin, kbOpen ->
        RemoteUiState(
            activeTv = session.activeTv,
            connectionState = session.connectionState,
            statusError = session.statusError,
            isDeviceSheetOpen = discovery.isDeviceSheetOpen,
            isScanning = discovery.isScanning,
            discoveredDevices = discovery.discoveredDevices,
            savedDevices = discovery.savedDevices,
            discoveryError = discovery.discoveryError,
            pinDialog = pin,
            isKeyboardDialogOpen = kbOpen,
            isMuted = session.isMuted
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = RemoteUiState()
    )

    private data class DiscoverySlice(
        val isDeviceSheetOpen: Boolean,
        val isScanning: Boolean,
        val discoveredDevices: List<DiscoveredTv>,
        val savedDevices: List<SavedTvDevice>,
        val discoveryError: String?
    )

    private data class SessionSlice(
        val activeTv: SavedTvDevice?,
        val connectionState: ConnectionState,
        val statusError: String?,
        val isMuted: Boolean
    )

    init {
        val lastTv = repository.getLastConnectedDevice()
        if (lastTv != null) {
            connectToSavedTv(lastTv)
        } else {
            openDevicePicker()
        }
    }

    fun openDevicePicker() {
        _isDeviceSheetOpen.value = true
        discoveryManager.startDiscovery()
    }

    fun closeDevicePicker() {
        _isDeviceSheetOpen.value = false
        discoveryManager.stopDiscovery()
    }

    fun refreshDiscovery() {
        discoveryManager.stopDiscovery()
        discoveryManager.startDiscovery()
    }

    fun connectToSavedTv(device: SavedTvDevice) {
        _localError.value = null
        _activeTv.value = device
        repository.setLastConnectedHost(device.host)
        closeDevicePicker()
        sessionClient.connect(device.host, device.port)
    }

    fun startPairingWithDiscovered(tv: DiscoveredTv) {
        startPairing(name = tv.displayName, host = tv.host, remotePort = tv.port)
    }

    fun startPairingWithManualIp(rawIp: String) {
        val host = rawIp.trim()
        if (host.isEmpty()) return
        startPairing(name = host, host = host, remotePort = SavedTvDevice.DEFAULT_REMOTE_PORT)
    }

    private fun startPairing(name: String, host: String, remotePort: Int) {
        pairingJob?.cancel()
        closeDevicePicker()
        sessionClient.disconnect()
        _localError.value = null

        val existingSaved = repository.savedDevices.value.firstOrNull { it.host == host }
        if (existingSaved != null) {
            connectToSavedTv(existingSaved)
            return
        }

        pairingJob = viewModelScope.launch {
            val result = pairingClient.pairWithTv(
                host = host,
                port = PairingClient.PAIRING_PORT,
                onReadyForPin = { tvName ->
                    val deferred = pinPromptChannel.createRequest()
                    _pinDialog.value = PinDialogState(tvName = tvName.ifBlank { name }, host = host)
                    deferred.await()
                }
            )

            when (result) {
                is PairingResult.Success -> {
                    _pinDialog.value = null
                    val saved = SavedTvDevice(
                        name = result.serverName.ifBlank { name },
                        host = host,
                        port = remotePort
                    )
                    repository.savePairedDevice(saved)
                    _activeTv.value = saved
                    sessionClient.connect(saved.host, saved.port)
                }
                is PairingResult.Failure -> {
                    _pinDialog.value = null
                    _localError.value = result.reason
                }
            }
        }
    }

    fun submitPairingPin(pin: String) {
        val clean = pin.trim().uppercase()
        if (PairingClient.parseHexPin(clean) == null) {
            _pinDialog.value = _pinDialog.value?.copy(
                error = "Enter a valid 6-character hex code (0-9, A-F)"
            )
            return
        }
        _pinDialog.value = _pinDialog.value?.copy(isVerifying = true, error = null)
        pinPromptChannel.submitPin(clean)
    }

    fun cancelPairing() {
        pinPromptChannel.cancel()
        pairingJob?.cancel()
        _pinDialog.value = null
    }

    fun forgetSavedDevice(host: String) {
        repository.removePairedDevice(host)
        if (_activeTv.value?.host == host) {
            sessionClient.disconnect()
            _activeTv.value = null
        }
    }

    fun sendKey(keyCode: RemoteKeyCode, direction: RemoteDirection = RemoteDirection.SHORT) {
        viewModelScope.launch {
            sessionClient.sendKey(keyCode, direction)
        }
    }

    fun startVolumeRepeat(keyCode: RemoteKeyCode) {
        volumeRepeatJob?.cancel()
        volumeRepeatJob = viewModelScope.launch {
            sessionClient.sendKey(keyCode, RemoteDirection.SHORT)
            delay(320L)
            while (isActive) {
                sessionClient.sendKey(keyCode, RemoteDirection.SHORT)
                delay(110L)
            }
        }
    }

    fun stopVolumeRepeat() {
        volumeRepeatJob?.cancel()
        volumeRepeatJob = null
    }

    fun openKeyboardDialog() {
        _isKeyboardDialogOpen.value = true
    }

    fun closeKeyboardDialog() {
        _isKeyboardDialogOpen.value = false
    }

    fun sendImeText(text: String) {
        viewModelScope.launch {
            sessionClient.sendTextBatch(text)
            _isKeyboardDialogOpen.value = false
        }
    }

    fun launchYouTube() {
        viewModelScope.launch {
            sessionClient.launchAppLink(YOUTUBE_APP_LINK)
        }
    }

    fun launchNetflix() {
        viewModelScope.launch {
            sessionClient.launchAppLink(NETFLIX_APP_LINK)
        }
    }

    override fun onCleared() {
        super.onCleared()
        discoveryManager.stopDiscovery()
        sessionClient.disconnect()
        pinPromptChannel.cancel()
    }

    companion object {
        const val YOUTUBE_APP_LINK = "https://www.youtube.com"
        const val NETFLIX_APP_LINK = "https://www.netflix.com/title"
    }
}
