package com.tvremote.gtv.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvremote.gtv.data.SavedTvDevice
import com.tvremote.gtv.discovery.DiscoveredTv
import com.tvremote.gtv.ui.theme.GtvColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicePickerBottomSheet(
    isScanning: Boolean,
    savedDevices: List<SavedTvDevice>,
    discoveredDevices: List<DiscoveredTv>,
    discoveryError: String?,
    onDismiss: () -> Unit,
    onRefreshScan: () -> Unit,
    onSelectSaved: (SavedTvDevice) -> Unit,
    onForgetSaved: (String) -> Unit,
    onSelectDiscovered: (DiscoveredTv) -> Unit,
    onSubmitManualIp: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var manualIp by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = GtvColors.Surface,
        contentColor = GtvColors.TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Select Android TV",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GtvColors.TextPrimary
                    )
                    Text(
                        text = if (isScanning) "Scanning Wi-Fi via mDNS (_androidtvremote2._tcp)" else "Wi-Fi scan paused",
                        fontSize = 12.sp,
                        color = GtvColors.TextSecondary
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = GtvColors.AccentBlue
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    IconButton(onClick = onRefreshScan) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Rescan TVs",
                            tint = GtvColors.TextPrimary
                        )
                    }
                }
            }

            if (!discoveryError.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = discoveryError,
                    color = GtvColors.StatusDisconnected,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (savedDevices.isNotEmpty()) {
                    item {
                        Text(
                            text = "Saved Paired TVs",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = GtvColors.TextSecondary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    items(savedDevices, key = { "saved_${it.host}" }) { saved ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = GtvColors.SurfaceElevated,
                            border = BorderStroke(1.dp, GtvColors.BorderHairline),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectSaved(saved) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Bookmark,
                                    contentDescription = null,
                                    tint = GtvColors.AccentBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = saved.name,
                                        color = GtvColors.TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${saved.host}:${saved.port} · Paired",
                                        color = GtvColors.TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                IconButton(onClick = { onForgetSaved(saved.host) }) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "Forget ${saved.name}",
                                        tint = GtvColors.TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Discovered on Local Network",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GtvColors.TextSecondary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                if (discoveredDevices.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = GtvColors.Background,
                            border = BorderStroke(1.dp, GtvColors.BorderHairline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isScanning) {
                                    "Looking for Google TV & Android TV devices on the same Wi-Fi..."
                                } else {
                                    "No TVs discovered yet. Tap refresh or enter your TV's IP address below."
                                },
                                color = GtvColors.TextSecondary,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(discoveredDevices, key = { "disc_${it.host}" }) { tv ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = GtvColors.SurfaceElevated,
                            border = BorderStroke(1.dp, GtvColors.BorderHairline),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectDiscovered(tv) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Tv,
                                    contentDescription = null,
                                    tint = GtvColors.TextPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = tv.displayName,
                                        color = GtvColors.TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${tv.host}:${tv.port}",
                                        color = GtvColors.TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                Text(
                                    text = "Pair",
                                    color = GtvColors.AccentBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = GtvColors.BorderHairline)
            Spacer(Modifier.height(14.dp))

            Text(
                text = "Manual IP Address Fallback",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = GtvColors.TextSecondary
            )
            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = manualIp,
                    onValueChange = { manualIp = it },
                    placeholder = { Text("192.168.1.42", color = GtvColors.TextSecondary) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(
                        onGo = { if (manualIp.isNotBlank()) onSubmitManualIp(manualIp) }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GtvColors.AccentBlue,
                        unfocusedBorderColor = GtvColors.BorderHairline,
                        focusedTextColor = GtvColors.TextPrimary,
                        unfocusedTextColor = GtvColors.TextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = { onSubmitManualIp(manualIp) },
                    enabled = manualIp.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GtvColors.AccentBlue,
                        contentColor = GtvColors.Background
                    ),
                    modifier = Modifier.height(54.dp)
                ) {
                    Text("Connect", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
