package com.tvremote.gtv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tvremote.gtv.ui.RemoteScreen
import com.tvremote.gtv.ui.RemoteViewModel
import com.tvremote.gtv.ui.theme.GtvRemoteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            GtvRemoteTheme {
                val remoteViewModel: RemoteViewModel = viewModel()
                RemoteScreen(viewModel = remoteViewModel)
            }
        }
    }
}
